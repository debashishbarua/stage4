package com.cts.springboot;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

@Service
public class StudentService {

	private List<Student> students = new ArrayList<Student>();

	public StudentService() {
		ApplicationContext ctx = new ClassPathXmlApplicationContext("studentConfig.xml");
		students = ctx.getBean("studentList", java.util.ArrayList.class);
	}

	public List<Student> getAllStudent() {

		return students;
	}

	public Student findById(String id) {
		Student student = null;
		for (Student s : students) {
			if (s.getId().equals(id))
				student = s;
		}
		return student;
	}
	
	public Student create(Student student) {		
		if(students.add(student)) {
			return student;
		}
		return null;
	}

}
