package com.cts.springboot;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GoodMorningController {
	
	@GetMapping("/goodmorning")
	public String sayGoodMorning() {
		return "Good Morning";
	}

}
