package com.example.demo.resources;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.repositories.EmployeeRepository;

@RestController
@RequestMapping("/employees")
public class EmployeeResources {

	@Autowired
	private EmployeeRepository repository;

	@GetMapping("/{name}")
	public Employee getEmployeeByName(@PathVariable("name") String name) {

		return repository.findByName(name);

	}

	@PostMapping
	public Employee save(@RequestBody Employee employee) {

		return repository.save(employee);

	}

}
