package com.example.demo.controllers;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dtos.TeachingClassDto;
import com.example.demo.services.TeachingClassService;

@RestController("/class")
public class TeachingClassController {

	private final TeachingClassService teachingClassService;

	public TeachingClassController(TeachingClassService teachingClassService) {
		this.teachingClassService = teachingClassService;
	}

	@GetMapping
	public List<TeachingClassDto> listClasses() {
		return teachingClassService.listClasses();
	}

}
