insert into countries (country,name,currency,currencysimbol,language,capital) 
values('es','España','Euro','€','es-ES','Madrid');
insert into countries (country,name,currency,currencysimbol,language,capital) 
values('en','Inglaterra','Libra Esterlina','£','en-EN','London');
insert into countries (country,name,currency,currencysimbol,language,capital) 
values('eu','United Stated','Dollar','$','en-EU','Washington');