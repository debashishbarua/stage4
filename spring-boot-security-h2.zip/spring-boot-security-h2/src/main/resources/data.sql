insert into users values('user','pass',true);
insert into users values('admin','pass',true);

insert into authorities values('user','ROLE_USER');
insert into authorities values('admin','ROLE_ADMIN');
