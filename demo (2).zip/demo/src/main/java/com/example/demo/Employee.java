package com.example.demo;

//@XmlRootElement(name = "employee")
//@JacksonXmlRootElement(localName = "employee")
public class Employee {
	
	//@XmlAttribute
	//@JacksonXmlProperty(isAttribute = true)
	//@JacksonXmlProperty
	private Long id;
	
//	@XmlElement
	//@JacksonXmlProperty
	private String name;
	
	//@XmlElement
	//@JacksonXmlProperty
	private String city;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(Long id, String name, String city) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", city=" + city + "]";
	}
}
