package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class EmployeeService {

	private List<Employee> employees = new ArrayList<Employee>();

	public EmployeeService() {
		employees.add(new Employee(1000L, "Akash", "Kolkata"));
		employees.add(new Employee(1001L, "Akash", "Kolkata"));
		employees.add(new Employee(1002L, "Akash", "Kolkata"));
	}

	public List<Employee> getEmployees() {

		return employees;
	}

	public Employee getEmployeeById(Long id) {
		for (Employee employee : employees) {
			//System.out.println(employee);
			if (employee.getId().equals(id)) {
				return employee;
			}
		}
		return null;
	}

}
