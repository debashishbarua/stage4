package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

	//@RequestMapping(value = "/employees", produces = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	@RequestMapping(value = "/employees")
	public Employees getAllEmployees() {

		List<Employee> list = new ArrayList<Employee>();

		Employee empOne = new Employee(1L, "Lokesh Gupta", "Kolkata");
		Employee empTwo = new Employee(2L, "Amit Singhal", "Delhi");
		Employee empThree = new Employee(3l, "Kirti Mishra", "Mumbai");

		list.add(empOne);
		list.add(empTwo);
		list.add(empThree);

		Employees employees = new Employees();
		employees.setEmployees(list);
		return employees;
	}

	//@RequestMapping(value = "/employees/{id}", produces =  {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE},consumes = {MediaType.APPLICATION_XML_VALUE,MediaType.APPLICATION_JSON_VALUE})
	@RequestMapping(value = "/employees/{id}")
	public Employee getEmployeeById(@PathVariable("id") int id) {
		if (id <= 3) {
			Employee employee = new Employee(1L, "Lokesh Gupta", "Kolkata");
			return employee;
		}
		return null;
	}

}
