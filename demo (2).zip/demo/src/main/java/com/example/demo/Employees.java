package com.example.demo;

import java.util.ArrayList;
import java.util.List;

//@XmlRootElement(name = "employees")
//@JacksonXmlRootElement
public class Employees {
	
	//@XmlElement(name = "employee")
  //  @JacksonXmlProperty(localName = "employee")
  //  @JacksonXmlElementWrapper(useWrapping = false)
	private List<Employee> employees = new ArrayList<>();

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

}
