/**
 * 
 */
package com.example.demo;

import static org.hamcrest.CoreMatchers.*;

import static org.junit.jupiter.api.Assertions.fail;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.ArgumentMatchers.any;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author Debashish
 *
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class BookControllerTest {

	private static final ObjectMapper om = new ObjectMapper();
	
	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private BookRepository mockRepository;

	@Test
	public void save_emptyAuthor_emptyPrice_400() throws Exception {
		String bookInJson = "{\"name\":\"ABC\"}";
		mockMvc.perform(post("/books")
				.content(bookInJson)
				.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
				.andDo(print())
				.andExpect(status().isBadRequest())
				.andExpect(jsonPath("$.timestamp", is(notNullValue())))
				.andExpect(jsonPath("$.status", is(400)))
				.andExpect(jsonPath("$.errors").isArray())
				//.andExpect(jsonPath("$.errors", hasItem(3)))
				.andExpect(jsonPath("$.errors", hasItem("Author is not allowed.")))
				.andExpect(jsonPath("$.errors", hasItem("Please provide a author")))
				.andExpect(jsonPath("$.errors", hasItem("Please provide a price")));

		verify(mockRepository, times(0)).save(any(Book.class));
	}
	
	
	@Test
	public void save_invalidAuthor_400() throws Exception {
	    String bookInJson = "{\"name\":\" Spring REST tutorials\", \"author\":\"abc\",\"price\":\"9.99\"}";
	    mockMvc.perform(post("/books")
	            .content(bookInJson)
	            .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON))
	            .andDo(print())
	            .andExpect(status().isBadRequest())
	            .andExpect(jsonPath("$.timestamp", is(notNullValue())))
	            .andExpect(jsonPath("$.status", is(400)))
	            .andExpect(jsonPath("$.errors").isArray())
	            //.andExpect(jsonPath("$.errors", hasItem()))
	            .andExpect(jsonPath("$.errors", hasItem("Author is not allowed.")));
	
	    verify(mockRepository, times(0)).save(any(Book.class));
	}


}