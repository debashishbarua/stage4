package com.cts.springboot;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Student {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Student.class);
	
	private String id;
	private String name;
	
	public Student() {
		//System.out.println("Student Initialized");
		LOGGER.debug("Insise the Student Constructor");
	}

	public String getId() {
		
		return id;
	}

	public void setId(String id) {
		LOGGER.debug("Set Id : {}" ,id);
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		LOGGER.debug("Set Name : {}" ,name);
		this.name = name;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + "]";
	}
	
	
	

}
