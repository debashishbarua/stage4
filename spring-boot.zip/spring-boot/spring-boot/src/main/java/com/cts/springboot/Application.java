package com.cts.springboot;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Application {

	private static final Logger LOGGER = LoggerFactory.getLogger(Application.class);
	
	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
		displayStudentList();
	}

	
	public static void displayStudent() {		
		/*
		 * LOGGER.debug("START"); //Initialize the context ApplicationContext context =
		 * new ClassPathXmlApplicationContext("studentConfig.xml"); Student student=
		 * context.getBean("student",Student.class); Student anotheStudent=
		 * context.getBean("student",Student.class); //System.out.println(student);
		 * //System.out.println(anotheStudent); LOGGER.debug("Student : {} ", student);
		 * LOGGER.debug("END");
		 */
		
	}
	
	public static void displayStudentList() {
		
		LOGGER.debug("START");
		//Initialize the context
		ApplicationContext context = new ClassPathXmlApplicationContext("studentConfig.xml");		
		ArrayList<Student> studentList= context.getBean("studentList",ArrayList.class);
		LOGGER.debug("Student List : {} ", studentList);
		LOGGER.debug("END");
		
	}
}
