package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/books")
public class BookController {
	
	private List<Book> list=new ArrayList<Book>();
	
	@GetMapping
	public List<Book> getAllBooks(){		
		list.add(new Book(1, "Raj Kumar", "C++"));
		list.add(new Book(2, "Raj Kumar", "C"));
		return list;
		
	}
	
	@GetMapping("/{id}")
	public Book getBookById(@PathVariable("id") int id){		
		return new Book(1, "Raj Kumar", "C++");		
	}

}
