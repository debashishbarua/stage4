package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Employee;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@Service
public class EmployeeClientService {

	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "meth")
	public Employee getEmployeeByName(String name) {
		Employee employee = null;
		String url = "http://employee-service/employees/" + name;
		employee = restTemplate.getForObject(url, Employee.class);
		return employee;

	}

	public Employee meth(String name) {
		
		return new Employee();
	}

}
