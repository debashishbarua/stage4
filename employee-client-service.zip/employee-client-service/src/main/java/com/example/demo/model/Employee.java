package com.example.demo.model;

import lombok.Data;

@Data
public class Employee {
	private Integer id;
	private String name;
	private String city;
	private Double salary;

}
