package com.example.demo.resourecs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.example.demo.model.Employee;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/client/employees")
public class EmployeClientResource {

	@Autowired
	private RestTemplate restTemplate;

	@HystrixCommand(fallbackMethod = "meth")
	@GetMapping("/{name}")
	public Employee getEmployeeByName(@PathVariable("name") String name) {
		Employee employee = null;
		String url = "http://employee-service/employees/" + name;
		employee = restTemplate.getForObject(url, Employee.class);
		return employee;

	}

	public Employee meth() {
		log.debug("-------------fallback--start----------------");
		return new Employee();
	}

}
