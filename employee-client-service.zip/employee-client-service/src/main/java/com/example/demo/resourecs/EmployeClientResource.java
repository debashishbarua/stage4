package com.example.demo.resourecs;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeClientService;

@RestController
@RequestMapping("/client/employees")
@EnableCircuitBreaker
public class EmployeClientResource {

	@Autowired
	private EmployeeClientService service;

	@GetMapping("/{name}")
	public Employee getEmployeeByName(@PathVariable("name") String name) {
		return service.getEmployeeByName(name);

	}

}
